package com.beyontec.mdcp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.beyontec.mdcp.model.Test;
import com.beyontec.mdcp.repo.UserRepo;

@Service
public class UserService {
	
	@Autowired
	private UserRepo userRepo;

	public void testDatabase(Test test) {
		// TODO Auto-generated method stub
		
		userRepo.save(test);
		
	}

}
