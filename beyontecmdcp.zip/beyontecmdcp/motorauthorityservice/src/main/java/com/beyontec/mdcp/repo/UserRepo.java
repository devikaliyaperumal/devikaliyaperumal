package com.beyontec.mdcp.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.beyontec.mdcp.model.Test;

@Repository
public interface UserRepo extends JpaRepository<Test, Integer>{

}
