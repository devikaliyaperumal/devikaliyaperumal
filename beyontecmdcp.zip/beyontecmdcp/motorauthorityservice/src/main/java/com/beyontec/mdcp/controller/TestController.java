package com.beyontec.mdcp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.beyontec.mdcp.model.Test;
import com.beyontec.mdcp.service.UserService;

@RestController
@RequestMapping("/app")
public class TestController {
	
	
	@Autowired 
	private UserService userService;
	
	
	@PostMapping("/test")
	public String testApp(@RequestBody Test test) {
		userService.testDatabase(test);
		
		return "YES WORKING FINE......";
	}

}
